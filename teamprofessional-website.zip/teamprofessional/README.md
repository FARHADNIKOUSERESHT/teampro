# تیم حرفه‌ای‌ها | Teamprofessional

سایت حرفه‌ای و کاملاً رایگان برای دوره‌های مربیگری و دانش‌افزایی، آماده برای میزبانی روی **GitHub Pages**.

## ویژگی‌ها

- طراحی مدرن و ریسپانسیو (موبایل و دسکتاپ)
- پشتیبانی کامل از زبان فارسی (RTL)
- فونت زیبای Vazirmatn
- بخش‌های مختلف:
  - صفحه اصلی با آمار
  - درباره ما
  - دوره‌های تخصصی (مربیگری، دانش‌افزایی، رهبری، مهارت نرم و ...)
  - فرم تماس
  - فوتر کامل

## نحوه انتشار روی GitHub Pages (رایگان)

### روش ۱: ساده و سریع

1. وارد [GitHub.com](https://github.com) شوید و حساب بسازید (اگر ندارید).
2. یک مخزن (Repository) جدید بسازید:
   - نام پیشنهادی: `teamprofessional` یا `username.github.io`
   - Public انتخاب کنید.
3. فایل‌های این پوشه (`index.html`, `styles.css`, `script.js`) را آپلود کنید.
4. به Settings → Pages بروید.
5. در بخش Source گزینه **Deploy from a branch** را انتخاب کنید.
6. Branch را روی `main` (یا `master`) و پوشه `/ (root)` بگذارید و Save کنید.
7. چند دقیقه صبر کنید. سایت شما در آدرس زیر در دسترس خواهد بود:

```
https://YOUR-USERNAME.github.io/teamprofessional/
```

یا اگر نام مخزن را `YOUR-USERNAME.github.io` گذاشته‌اید:

```
https://YOUR-USERNAME.github.io/
```

### روش ۲: با Git (حرفه‌ای‌تر)

```bash
git clone https://github.com/YOUR-USERNAME/teamprofessional.git
cd teamprofessional
# فایل‌ها را کپی کنید
git add .
git commit -m "Add Teamprofessional website"
git push origin main
```

سپس از Settings → Pages فعال کنید.

## سفارشی‌سازی

- شماره تلفن و ایمیل را در بخش Contact تغییر دهید.
- متن‌ها و دوره‌ها را مطابق نیاز خود ویرایش کنید.
- رنگ‌ها در فایل `styles.css` در بخش `:root` قابل تغییر هستند.

## مجوز

این پروژه برای استفاده شخصی و تجاری رایگان است.

---

ساخته شده با ❤️ برای تیم حرفه‌ای‌ها
